from sklearn.metrics import classification_report


class SciKitClassifier:
    def __init__(self, model):
        self.model = model

    def run(self, data):
        self.model.fit(data.train_x, data.train_y)
        val_pred = self.model.predict(data.val_x)
        print(classification_report(data.val_y, val_pred, output_dict=False))

