import subprocess
from pathlib import Path

import cv2
import ffmpeg
import imageio as iio
import numpy as np
import skvideo.io as sio
from scipy.interpolate import interp1d


# class VideoRepair:
#     def __init__(self, output_path: Path):
#         if not output_path.is_dir():
#             output_path.mkdir()
#         self._output_path = output_path
#
#         self.deleted = 0
#         self.copied = 0
#         self.corrected = 0
#
#     def run(self, filepath: Path):
#         def printer(original_fps, output_fps, frames, original_frames):
#             if frames - original_frames > 0:
#                 print(f'Corrected: {original_fps} {original_frames} vs {output_fps} {frames}')
#                 self.corrected += 1
#             elif frames - original_frames == 0:
#                 print(f'Copied: {original_fps} {original_frames} vs {output_fps} {frames}')
#                 self.copied += 1
#             else:
#                 print('something went wrong1...')
#         output_filepath = self._output_path / f'{filepath.stem}.mkv'
#         if output_filepath.is_file():
#             _, original_frames = get_video_meta(filepath)
#             duration, frames = get_video_meta(output_filepath)
#             printer(original_frames/duration, frames/duration, frames, original_frames)
#             return output_filepath
#
#         _, original_frames = get_video_meta(filepath)
#         copy_file(filepath, output_filepath)
#
#         duration, frames = get_video_meta(output_filepath)
#         fps = frames / duration
#         if 15 < fps < 25:
#             print(f'To correct: {fps} {frames}')
#             self.corrected += 1
#         elif fps <= 15:
#             print(f'Deleted: {fps} {frames}')
#             self.deleted += 1
#         else:
#             print('something went wrong2...')
#
#         output_filepath.unlink()


class VideoRepair:
    def __init__(self, output_path: Path):
        if not output_path.is_dir():
            output_path.mkdir()
        self._output_path = output_path

    def run(self, filepath: Path):
        output_filepath = self._output_path / f'{filepath.stem}.mkv'
        if output_filepath.is_file():
            return output_filepath

        _, original_frames = get_video_meta(filepath)
        copy_file(filepath, output_filepath)

        duration, frames = get_video_meta(output_filepath)
        fps = frames / duration

        assert 0 < fps < 31, f'Error while calculating fps of video: {fps, duration, frames, filepath}'
        assert original_frames - frames == 0, f'Error while copying video: {original_frames, frames, filepath}'

        if 15 < fps < 25:
            output_filepath.unlink()
            # try:
            #     video_path = increase_video_fps(filepath, duration, output_filepath)
            #     combine_video_audio(video_path, filepath, output_filepath)
            #     video_path.unlink()
            # except np.core._exceptions._ArrayMemoryError as err:
            video_path_rescaled = output_filepath.with_name(f'{output_filepath.stem}_rescaled.mkv')
            rescale_video(filepath, 2, fps, video_path_rescaled)

            video_path = increase_video_fps(video_path_rescaled, duration, output_filepath)
            combine_video_audio(video_path, filepath, output_filepath)
            video_path.unlink()
            video_path_rescaled.unlink()
        elif fps <= 15:
            output_filepath.unlink()

        return output_filepath


def copy_file(filepath, output_filepath):
    proc = subprocess.run(
        ["ffmpeg", "-i", filepath, "-c", "copy", "-movflags", "use_metadata_tags", "-map_metadata", "0",
         output_filepath], capture_output=True)
    if proc.returncode:
        print(f"An error occured while processing video {filepath}:")
        print(proc.stdout, proc.stderr)


def get_video_meta(filepath: Path):
    video = iio.get_reader(filepath, 'ffmpeg')
    duration = video._meta['duration']
    frames = video.count_frames()

    return duration, frames


def needs_correction(fps) -> bool:
    if 15 < fps < 25:
        return True
    return False


def video_to_array(filepath: Path) -> np.array:
    buf = sio.vread(str(filepath))
    return buf


def interpolate_video(video: np.array, target_frames: int) -> np.array:
    frames, height, width, channels = video.shape

    new_video = np.zeros([target_frames, height, width, channels], dtype='uint8')
    for i in range(height):
        for j in range(width):
            for c in range(channels):
                x_new = np.linspace(0, frames, target_frames)
                x = np.linspace(0, frames, frames)
                y = video[:, i, j, c]
                video_inter = interp1d(x, y)
                y_new = video_inter(x_new)
                new_video[:, i, j, c] = y_new

    return new_video


def array_to_video(array: np.array, target_fps: float, output_filepath: Path) -> Path:
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # codec
    out = cv2.VideoWriter(str(output_filepath), fourcc, target_fps, (array.shape[2], array.shape[1]))
    for i in range(array.shape[0]):
        frame = cv2.cvtColor(array[i], cv2.COLOR_BGR2RGB)
        out.write(frame)
    out.release()

    return output_filepath


def increase_video_fps(filepath, duration, output_filepath):
    video = video_to_array(filepath)
    video_path = output_filepath.with_name(f'{output_filepath.stem}_video.mkv')

    target_frames = int(duration * 30)
    video = interpolate_video(video, target_frames)

    target_fps = target_frames / duration
    array_to_video(video, target_fps, video_path)

    return video_path


def rescale_video(filepath, factor, fps, output_filepath):
    video = video_to_array(filepath)
    width, height = video.shape[2] // factor, video.shape[1] // factor
    print(f'Rescaling video: {filepath}.{width}.{height}.')
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # codec
    out = cv2.VideoWriter(str(output_filepath), fourcc, fps, (width, height))

    # Read and resize each frame
    for i in range(video.shape[0]):
        frame = cv2.cvtColor(video[i], cv2.COLOR_BGR2RGB)
        resized_frame = cv2.resize(frame, (width, height))
        out.write(resized_frame)

    out.release()


def combine_video_audio(video: Path, audio: Path, output_path: Path) -> Path:
    v = ffmpeg.input(video)
    a = ffmpeg.input(audio)
    ffmpeg.concat(v, a, v=1, a=1).output(str(output_path)).run()
    return output_path


def main():
    from tqdm import tqdm
    from mbp.data_preparation.loader import Loader
    from examples.sit.datasets import sit_datasets

    for dataset in sit_datasets.values():
        print(f'Extracting dataset from: {dataset.raw}...')
        loader = Loader(dataset.raw, dataset.video_extension)
        data = loader.get()

        output_path = dataset.processed / 'repaired'
        repairer = VideoRepair(output_path)

        for index, video in tqdm(data.iterrows(), total=len(data)):
            repairer.run(video['Path'])


if __name__ == '__main__':
    main()
