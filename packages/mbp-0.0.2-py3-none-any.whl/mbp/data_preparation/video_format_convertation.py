import subprocess

from pathlib import Path


class VideoConverter:
    def __init__(self, target_extension: str, output_path: Path):
        self._target_extension = target_extension
        if not output_path.is_dir():
            output_path.mkdir()
        self._output_path = output_path

    def convert(self, filepath: Path):
        output_filename = self._output_path / f'{filepath.stem}.{self._target_extension}'
        if output_filename.is_file():
            return output_filename
        proc = subprocess.run(
            ["ffmpeg", "-i", filepath, "-r", "30", "-vcodec", "ffv1", "-acodec", "pcm_s16le", output_filename],
            capture_output=True)

        if proc.returncode:
            print(f"An error occured while processing video {filepath}:")
            print(proc.stdout, proc.stderr)

        return output_filename
