import pandas as pd

from pathlib import Path
from typing import Union


class Loader:
    def __init__(self, dataset_path: Union[str, Path], extensions: list):
        self._dataset_path = Path(dataset_path)
        self._extensions = extensions

    def get(self) -> pd.DataFrame:
        data = []
        for extension in self._extensions:
            data.extend(self._dataset_path.rglob(extension))
        data = pd.DataFrame(data, columns=['Path'])
        return data
