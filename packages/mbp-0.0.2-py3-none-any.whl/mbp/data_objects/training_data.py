import pandas as pd

from dataclasses import dataclass


@dataclass
class TrainingData:
    train_x: pd.DataFrame
    val_x: pd.DataFrame
    train_y: pd.DataFrame
    val_y: pd.DataFrame
