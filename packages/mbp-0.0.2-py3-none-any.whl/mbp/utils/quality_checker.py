import logging
import imageio
import pandas as pd

from datetime import datetime
from pathlib import Path
from tqdm import tqdm
from typing import Union, Tuple, List

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%d-%b-%y %H:%M:%S',
    level=logging.NOTSET
)


def extract_video_metadata(
        filepath: Union[str, Path]) -> Tuple[float, float, int, datetime]:
    """
    Extract video metadata.

    Parameters:
        filepath (Union[str, Path]): Path to the video file.

    Returns:
        Tuple[float, float, int, datetime]: Video duration (seconds),
            frames per second (FPS),
            total number of frames, and modification time of the file.

    """
    try:
        with imageio.get_reader(filepath, 'ffmpeg') as video:
            duration = video.get_meta_data()['duration']
            fps = video.get_meta_data()['fps']
            frames = video.count_frames()
        mtime = datetime.fromtimestamp(filepath.stat().st_mtime)
    except imageio.core.format.CannotReadFrameError as e:
        logging.error(f'Error reading video frames: {e}')
        duration, fps, frames, mtime = 0, 0, 0, 0
    except OSError as e:
        logging.error(f'Error accessing file: {e}')
        duration, fps, frames, mtime = 0, 0, 0, 0
    except Exception as e:
        logging.error(f'Unexpected error occurred: {e}')
        duration, fps, frames, mtime = 0, 0, 0, 0
    return duration, fps, frames, mtime


class VideoQualityChecker:
    def __init__(self, data: List[Union[str, Path]]):
        logging.info('Initializing video quality checker...')
        self._data = data

    def check(self) -> pd.DataFrame:
        meta_info = []
        for video in tqdm(self._data):
            meta_info.append([video, *extract_video_metadata(video)])

        meta_info = pd.DataFrame(meta_info,
                                  columns=['path', 'duration', 'fps',
                                           'frames', 'mtime'])
        return meta_info


