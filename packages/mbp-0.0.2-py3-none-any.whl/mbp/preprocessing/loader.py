import logging

from pathlib import Path
from typing import Union, List

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%d-%b-%y %H:%M:%S',
    level=logging.NOTSET
)


class Loader:
    def __init__(self, dataset_path: Union[str, Path],
                 extensions: List[str]):
        """
        Initializes the Loader instance.

        Parameters:
            dataset_path (Union[str, Path]):
                The path to the folder containing video files.
            extensions (List[str]):
                List of file extensions to filter video files, e.g., ['*.webm']

        Raises:
           ValueError: If dataset_path is not a valid directory path.
        """
        logging.info('Initializing data loader...')
        self._dataset_path = Path(dataset_path)
        if not self._dataset_path.is_dir():
            raise ValueError("The dataset_path must be a valid directory path")
        self._extensions = extensions

    def load(self) -> List[Union[str, Path]]:
        """
        Load video files from the specified folder path with given extensions.

        Returns:
            List of file paths to video files.
        """
        data = []
        for extension in self._extensions:
            data.extend(self._dataset_path.rglob(extension))
        logging.info(f'Loaded {len(data)} files...')
        return data
