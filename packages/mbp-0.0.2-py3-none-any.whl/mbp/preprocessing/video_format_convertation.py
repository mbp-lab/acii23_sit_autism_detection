import subprocess
import logging

from pathlib import Path

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%d-%b-%y %H:%M:%S',
    level=logging.NOTSET
)


class VideoConverter:
    """
    Class to convert videos to a specified format using ffmpeg.
    """
    def __init__(self, target_extension: str, output_path: Path):
        """
        Initialize the VideoConverter.

        Parameters:
            target_extension (str): Extension for the converted videos.
            output_path (Path): The directory to save the converted videos.
        """
        self._target_extension = target_extension
        if not output_path.is_dir():
            output_path.mkdir(parents=True, exist_ok=True)
        self._output_path = output_path

    def run(self, filepath: Path) -> Path:
        """
        Convert a video file to the specified format.

        Parameters:
            filepath (Path): The path to the input video file.

        Returns:
            Path: The path to the converted video file.
        """
        output_filename = f'{filepath.stem}.{self._target_extension}'
        output_filepath = self._output_path / output_filename
        if output_filepath.is_file():
            return output_filepath
        process = subprocess.run(["ffmpeg", "-i", filepath,
                                  "-r", "30", "-vcodec", "ffv1",
                                  "-acodec", "pcm_s16le", output_filepath],
                                 capture_output=True)

        if process.returncode:
            logging.error(f"An error occurred while processing video: "
                          f"{filepath}:")
            logging.error(process.stdout, process.stderr)
            raise RuntimeError()

        return output_filepath
