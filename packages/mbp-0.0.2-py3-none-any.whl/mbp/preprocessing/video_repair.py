import subprocess
import cv2
import ffmpeg
import numpy as np
import skvideo.io as sio
import logging

from pathlib import Path
from typing import Union
from scipy.interpolate import interp1d

from mbp.utils.media_metadata import extract_video_metadata

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%d-%b-%y %H:%M:%S',
    level=logging.NOTSET
)


class VideoRepair:
    """
    Class to repair video files. Usually used for .webm format, as it has
    problems with some metadata, like duration, fps and others.
    Repairing is done by converting video files to mkv format and
    interpolating the FPS, if it is between 15 and 25.
    If FPS is lower than 15, the video will be excluded.
    """
    def __init__(self, output_path: Union[str, Path]):
        """
        Initialize the VideoRepair instance.

        Parameters:
            output_path (Union[str, Path]):
                The directory to save the repaired video files.
        """
        self._output_path = Path(output_path)
        if not self._output_path.is_dir():
            self._output_path.mkdir()

    def run(self, filepath: Union[str, Path]) -> Path:
        """
        Run the video repair process.

        Parameters:
            filepath (Union[str, Path]): The path to the input video file.

        Returns:
            Path: The path to the repaired video file.
        """
        filepath = Path(filepath)
        output_filepath = self._output_path / f'{filepath.stem}.mkv'
        if output_filepath.is_file():
            return output_filepath

        _, _, original_frames, _ = extract_video_metadata(filepath)
        copy_file(filepath, output_filepath)

        duration, fps, frames, _ = extract_video_metadata(output_filepath)
        fps = frames / duration if fps == 0 else fps

        if 0 < fps < 31:
            logging.error(f'FPS outside of the range (0, 31): {fps, filepath}')
            logging.error(f'Frame count and duration: {frames, duration}')
        if original_frames - frames != 0:
            logging.error(f'Missing frames while copying video: {filepath}')
            logging.error(f'Original: {original_frames}, copied:{frames}')

        if needs_correction(fps):
            output_filepath.unlink()
            try:
                correct_video(filepath, output_filepath,
                              output_filepath, duration)
            except Exception as err:
                logging.error(f'Error while interpolation: {err}')
                logging.error('Retrying by reducing the size of the video')
                video_path_rescaled = output_filepath.with_name(
                    f'{output_filepath.stem}_rescaled.mkv')
                rescale_video(filepath, 2, fps, video_path_rescaled)
                correct_video(filepath, video_path_rescaled,
                              output_filepath, duration)
                video_path_rescaled.unlink()

        elif fps <= 15:
            output_filepath.unlink()

        return output_filepath


def correct_video(original_filepath: Path,
                  video_filepath: Path,
                  output_filepath: Path,
                  duration: float):
    """
    Corrects video by increasing its FPS.

    Parameters:
        original_filepath (Path): The path to the original video file (w audio)
        video_filepath (Path): The path to the video file (w/wo audio)
        output_filepath (Path): The path to the output video file.
        duration (float): The duration of the video.

    Raises:
        Exception: If an error occurs during video correction.
    """
    try:
        video_path = increase_video_fps(video_filepath,
                                        duration,
                                        output_filepath)
        combine_video_audio(video_path, original_filepath, output_filepath)
        video_path.unlink()
    except Exception as err:
        raise Exception(f'Error occurred during video correction: {err}')


def copy_file(filepath: Path, output_filepath: Path):
    """
    Copies video file to the specified output path.

    Parameters:
        filepath (Path): The path to the input video file.
        output_filepath (Path): The path to the output video file.

    Raises:
        RuntimeError: If an error occurs during file copying.
    """
    process = subprocess.run(["ffmpeg", "-i", filepath, "-c", "copy",
                              "-movflags", "use_metadata_tags",
                              "-map_metadata", "0", output_filepath],
                             capture_output=True)
    if process.returncode:
        logging.error(f"An error occurred while processing video: "
                      f"{filepath}:")
        logging.error(process.stdout, process.stderr)
        raise RuntimeError()


def needs_correction(fps: float) -> bool:
    """
    Check if the video needs correction based on its FPS.

    Parameters:
        fps (float): Frames per second of the video.

    Returns:
        bool: True if the video needs correction, False otherwise.
    """
    return 15 < fps < 25


def video_to_array(filepath: Path) -> np.array:
    """
    Convert a video file to a numpy array.

    Parameters:
        filepath (Path): The path to the input video file.

    Returns:
        np.array: The numpy array representation of the video.
    """
    return sio.vread(str(filepath))


def array_to_video(array: np.array, target_fps: float,
                   output_filepath: Path) -> Path:
    """
    Convert a numpy array to a video file.

    Parameters:
        array (np.array): The numpy array representation of the video.
        target_fps (float): The target frames per second for the output video.
        output_filepath (Path): The path to save the output video file.

    Returns:
        Path: The path to the output video file.
    """
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # codec
    out = cv2.VideoWriter(str(output_filepath), fourcc, target_fps,
                          (array.shape[2], array.shape[1]))
    for i in range(array.shape[0]):
        frame = cv2.cvtColor(array[i], cv2.COLOR_BGR2RGB)
        out.write(frame)
    out.release()

    return output_filepath


def interpolate_video(video: np.array, target_frames: int) -> np.array:
    """
    Interpolate the frames of a video to match a target number of frames.

    Parameters:
        video (np.array): The numpy array representation of the video.
        target_frames (int): The target number of frames for the output video.

    Returns:
        np.array: The interpolated numpy array representation of the video.
    """
    frames, height, width, channels = video.shape

    new_video = np.zeros([target_frames, height, width, channels],
                         dtype='uint8')
    for i in range(height):
        for j in range(width):
            for c in range(channels):
                x_new = np.linspace(0, frames, target_frames)
                x = np.linspace(0, frames, frames)
                y = video[:, i, j, c]
                video_inter = interp1d(x, y)
                y_new = video_inter(x_new)
                new_video[:, i, j, c] = y_new

    return new_video


def increase_video_fps(filepath: Path, duration: float,
                       output_filepath: Path) -> Path:
    """
    Increase the frames per second (FPS) of a video to match a target duration.

    Parameters:
        filepath (Path): The path to the input video file.
        duration (float): The target duration of the output video in seconds.
        output_filepath (Path): The path to match the filename and
            save the output video file with the name "..._video.mkv"

    Returns:
        Path: The path to the output video file.
    """
    video = video_to_array(filepath)
    video_path = output_filepath.with_name(f'{output_filepath.stem}_video.mkv')

    target_frames = int(duration * 30)
    video = interpolate_video(video, target_frames)

    target_fps = target_frames / duration
    array_to_video(video, target_fps, video_path)

    return video_path


def rescale_video(filepath: Path, factor: float, fps: float,
                  output_filepath: Path):
    """
    Rescale the resolution of a video by a given factor.

    Parameters:
        filepath (Path): The path to the input video file.
        factor (float): The scaling factor (e.g., 2 for doubling the size).
        fps (float): The frames per second (FPS) of the output video.
        output_filepath (Path): The path to save the rescaled video file.

    Returns:
        None
    """
    video = video_to_array(filepath)
    width, height = video.shape[2] // factor, video.shape[1] // factor

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # codec
    out = cv2.VideoWriter(str(output_filepath), fourcc, fps, (width, height))

    # Read and resize each frame
    for i in range(video.shape[0]):
        frame = cv2.cvtColor(video[i], cv2.COLOR_BGR2RGB)
        resized_frame = cv2.resize(frame, (width, height))
        out.write(resized_frame)

    out.release()


def combine_video_audio(video: Path, audio: Path, output_path: Path) -> Path:
    """
    Combine a video file and an audio file into a single video file.

    Parameters:
        video (Path): The path to the video file.
        audio (Path): The path to the audio file.
        output_path (Path): The path to save the combined video file.

    Returns:
        Path: The path to the combined video file.
    """
    v = ffmpeg.input(video)
    a = ffmpeg.input(audio)
    ffmpeg.concat(v, a, v=1, a=1).output(str(output_path)).run()
    return output_path
