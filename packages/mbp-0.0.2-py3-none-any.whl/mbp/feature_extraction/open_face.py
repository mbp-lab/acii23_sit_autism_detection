import subprocess
import pandas as pd
import numpy as np
import logging

from pathlib import Path
from typing import Union, List

from mbp.feature_extraction.base import FeatureExtractor
from mbp.utils.media_metadata import extract_video_metadata

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%d-%b-%y %H:%M:%S',
    level=logging.NOTSET
)

# External libs paths
OPEN_FACE_PATH = Path('/vol/openface/OpenFace/build/bin/')
OPEN_FACE_EXECUTABLE_PATH = OPEN_FACE_PATH / 'FeatureExtraction'


def check_executable_path(executable_path: Path):
    if not executable_path.is_file():
        raise ValueError(f"Can't find OpenFace executable: {executable_path}")


class OpenFaceFeatureExtractor(FeatureExtractor):
    """
    Extract features from video files using OpenFace.
    """

    def __init__(self,
                 output_path: Union[str, Path],
                 executable_path: Union[str, Path] = OPEN_FACE_EXECUTABLE_PATH,
                 correct_timespan: bool = False,
                 **kwargs):
        """
        Initialize the OpenFaceFeatureExtractor.

        Parameters:
            output_path (Union[str, Path]): The path where the extracted
            features will be saved.
            executable_path (Union[str, Path]): The path to the OpenFace
            executable.
            correct_timespan (bool): Whether to correct the timespan in the
            output features.
            **kwargs: Additional parameters to be passed to OpenFace. E.g.,
            aus=True, au_static=True, pose=True, tracked=False, gaze=True.
            Visit OpenFace documentation for more information.
        """
        logging.info('Initializing OpenFace feature extraction...')
        super().__init__(output_path)

        self._executable_path = Path(executable_path)
        check_executable_path(self._executable_path)
        self._correct_timespan = correct_timespan
        self._parameters = kwargs

    def _get_command(self) -> List[str]:
        command = [self._executable_path,
                   '-f', self._filepath,
                   '-out_dir', self._output_path]
        additional_parameters = [f'-{k}' for k, v in
                                 self._parameters.items() if v]
        command.extend(additional_parameters)
        return command

    def run(self, filepath: Union[str, Path]) -> Path:
        """
        Extract features from a video file using OpenFace.

        Parameters:
            filepath (Union[str, Path]): The path to the video file.

        Returns:
            bool: True if extraction is successful, False otherwise.
        """
        self._filepath = Path(filepath)
        self._output_filename = (self._output_path /
                                 f'{self._filepath.stem}.csv')
        if not self._already_extracted():
            command = self._get_command()
            process = subprocess.run(command, capture_output=True)

            if process.returncode:
                logging.error(f"An error occurred while processing video: "
                              f"{self._filepath}:")
                logging.error(process.stdout, process.stderr)
                raise RuntimeError()
            if self._correct_timespan:
                self._correct_timespan_in_output()
        return self._output_filename

    def _already_extracted(self) -> bool:
        if not self._output_filename.is_file():
            return False

        try:
            processed_frame_count = len(pd.read_csv(self._output_filename))
            _, _, frames_count, _ = extract_video_metadata(self._filepath)
            missing_frame_count = frames_count - processed_frame_count
            # logging.info(f'Extracted frames: {processed_frame_count} '
            #              f'Missing frames count: {missing_frame_count} '
            #              f'File: {self._output_filename}')
            return missing_frame_count < 25
        except Exception as e:
            logging.error(f'An error occurred: {e}')
            return False

    def _correct_timespan_in_output(self):
        duration, _, _, _ = extract_video_metadata(self._filepath)
        features = pd.read_csv(self._output_filename)
        difference = abs(features['timestamp'].max() - duration)
        difference_threshold_seconds = 2
        if difference > difference_threshold_seconds:
            features['timestamp'] = np.linspace(0.0,
                                                duration,
                                                num=(len(features)))
            features.to_csv(self._output_filename, index=False)
