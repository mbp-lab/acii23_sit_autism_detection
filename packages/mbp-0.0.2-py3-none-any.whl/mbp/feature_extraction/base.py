from abc import ABC, abstractmethod
from typing import Union
from pathlib import Path


class FeatureExtractor(ABC):
    def __init__(self, output_path: Union[str, Path]):
        self._output_path = Path(output_path)
        self._filepath = None
        self._output_filename = None

    @abstractmethod
    def run(self, filepath: Union[str, Path]) -> Path:
        raise NotImplementedError()

    @abstractmethod
    def _already_extracted(self) -> bool:
        raise NotImplementedError()
