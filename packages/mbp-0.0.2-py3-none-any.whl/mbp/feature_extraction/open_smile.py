import opensmile
import logging

from pathlib import Path
from typing import Union

from mbp.feature_extraction.base import FeatureExtractor

logging.basicConfig(
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%d-%b-%y %H:%M:%S',
    level=logging.NOTSET
)


class OpenSmileFeatureExtractor(FeatureExtractor):
    """
    Extracts functional features using OpenSMILE.

    To use opensmile package, you will probably need to install the following:
    sudo apt-get install ffmpeg mediainfo
    """

    def __init__(self, output_path: Union[str, Path],
                 feature_set=opensmile.FeatureSet.eGeMAPSv02):
        """
        Initialize the OpenSmileFeatureExtractor.

        Parameters:
            feature_set (FeatureSet): The feature set to use for extraction.
        """
        logging.info('Initializing OpenSmile feature extraction...')
        super().__init__(output_path)

        self._lld_features_setting = opensmile.Smile(
            feature_set=feature_set,
            feature_level=opensmile.FeatureLevel.LowLevelDescriptors,
        )

        self._functional_features_setting = opensmile.Smile(
            feature_set=feature_set,
            feature_level=opensmile.FeatureLevel.Functionals,
        )

    def run(self, filepath: Union[str, Path],
            start=None, end=None) -> Path:
        """
        Run feature extraction on a given video/audio file.

        Parameters:
            filepath (Path, str): The path to the video/audio file.
            start (float): Optional start time for extraction.
            end (float): Optional end time for extraction.

        Returns:
            bool: True if extraction is successful, False otherwise.
        """
        self._filepath = Path(filepath)
        self._output_filename = (self._output_path /
                                 f'{filepath.stem}.csv')
        if not self._already_extracted():
            features = self._functional_features_setting.process_file(
                filepath,
                start=start,
                end=end
            )
            features.to_csv(self._output_filename, index=False)
        return self._output_filename

    def _already_extracted(self) -> bool:
        if self._output_filename.is_file():
            return True

        return False
